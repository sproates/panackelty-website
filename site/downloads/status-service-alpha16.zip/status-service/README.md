# Status service for Panackelty alpha.16

Install Panackelty alpha.16: https://panackelty.com/get-started/

From this directory, run:

    panack run --project panack.json 8082

In another terminal:

    curl -i http://127.0.0.1:8082/status

Each request reports an increasing count and decimal uptime in seconds.
Ctrl-C stops the server. Restarting resets the count and startup time.
The server listens on 127.0.0.1; use another port if 8082 is occupied.

Source, manifest, lockfile and the HTTP dependency are included. No dependency
setup or source checkout is needed. The compiler and stdlib come from your
installed alpha.16 toolchain.

The HTTP package is copied unchanged from the Panackelty v0.1.0-alpha.16 release:
https://github.com/sproates/panackelty/releases/tag/v0.1.0-alpha.16
The service adapts its http_state_closure example to display decimal uptime.
See LICENSE for the MIT licence.
